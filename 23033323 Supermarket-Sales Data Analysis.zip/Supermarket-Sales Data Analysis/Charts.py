import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset with date parsing
df = pd.read_csv('C:\\Users\\MUSAB\\OneDrive - Higher Education Commission\\Documents\\codes\\vscode files\\python\\data analysis\\OpenSrc_data\\Supermarket_Sales.csv', parse_dates=['Date'])

# Step 1: Check the data types
print(df.dtypes)

# Step 2: Convert 'gross margin percentage' to numeric if not already
df['gross margin percentage'] = pd.to_numeric(df['gross margin percentage'], errors='coerce')

# Step 3: Group by Product line to get total sales
product_sales = df.groupby('Product line')['Total'].sum().sort_values()

# Plot 1: Detailed Bar chart of Total Sales by Product Line (No palette to avoid the warning)
plt.figure(figsize=(12, 8))
sns.barplot(x=product_sales.values, y=product_sales.index)  # Removed palette argument
plt.title('Total Sales by Product Line', fontsize=16)
plt.xlabel('Total Sales (in $)', fontsize=12)
plt.ylabel('Product Line', fontsize=12)
plt.xticks(fontsize=10)
plt.yticks(fontsize=10)
for index, value in enumerate(product_sales.values):
    plt.text(value, index, f'${value:.2f}', va='center', fontsize=10)  # Adding labels to bars
plt.grid(True, linestyle='--', alpha=0.6)
plt.show()

# Step 4: Group by Date to calculate daily sales
daily_sales = df.groupby('Date')['Total'].sum()

# Plot 2: Detailed Line plot of Total Sales Over Time
plt.figure(figsize=(12, 8))
plt.plot(daily_sales.index, daily_sales.values, marker='o', color='b', linestyle='-', linewidth=2, markersize=5)
plt.title('Total Sales Over Time', fontsize=16)
plt.xlabel('Date', fontsize=12)
plt.ylabel('Total Sales (in $)', fontsize=12)
plt.xticks(rotation=45, fontsize=10)
plt.grid(True, linestyle='--', alpha=0.6)
plt.tight_layout()
plt.show()

# Step 5: Correlation Matrix and Detailed Heatmap
numerical_df = df.select_dtypes(include='number')
corr_matrix = numerical_df.corr()

# Plot 3: Detailed Heatmap of Correlation Matrix
plt.figure(figsize=(12, 8))
sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', linewidths=0.5, linecolor='black', cbar_kws={'label': 'Correlation Coefficient'})
plt.title('Correlation Matrix of Numerical Features', fontsize=14)
plt.xticks(fontsize=10, rotation=45)
plt.yticks(fontsize=10)
plt.tight_layout()
plt.show()

# Step 6: Descriptive Statistics
print("Descriptive Statistics for Numerical Features:")
print(numerical_df.describe())

# Step 7: Correlation of Numerical Features
print("Correlation Matrix of Numerical Features:")
print(numerical_df.corr())
