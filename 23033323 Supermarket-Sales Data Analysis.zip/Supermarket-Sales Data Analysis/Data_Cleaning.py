import pandas as pd
import numpy as np

# Load dataset
data = pd.read_csv('C:\\Users\\MUSAB\\OneDrive - Higher Education Commission\\Documents\\codes\\vscode files\\python\\data analysis\\OpenSrc_data\\Supermarket_Sales.csv')

# 1. Check for missing values
missing_values = data.isnull().sum()
print("Missing Values:\n", missing_values)

# 2. Drop duplicate rows if any
data = data.drop_duplicates()

# 3. Convert 'Date' and 'Time' columns to datetime format
data['Date'] = pd.to_datetime(data['Date'], format='%m/%d/%Y')
data['Time'] = pd.to_datetime(data['Time'], format='%H:%M').dt.time

# 4. Handle categorical columns: encoding 'Branch', 'City', 'Customer type', 'Gender', 'Product line', 'Payment'
data['Branch'] = data['Branch'].astype('category').cat.codes
data['City'] = data['City'].astype('category').cat.codes
data['Customer type'] = data['Customer type'].astype('category').cat.codes
data['Gender'] = data['Gender'].astype('category').cat.codes
data['Product line'] = data['Product line'].astype('category').cat.codes
data['Payment'] = data['Payment'].astype('category').cat.codes

# 5. Rename columns for better readability
data = data.rename(columns={
    'gross margin percentage': 'Gross_Margin_Percentage',
    'gross income': 'Gross_Income'
})

# 6. Normalize the numerical columns (optional, for analysis purposes)
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()

# Normalizing columns 'Unit price', 'Quantity', 'Tax 5%', 'Total', 'cogs', 'Gross_Income', 'Rating'
numerical_cols = ['Unit price', 'Quantity', 'Tax 5%', 'Total', 'cogs', 'Gross_Income', 'Rating']
data[numerical_cols] = scaler.fit_transform(data[numerical_cols])

# 7. Replacing any outliers or inconsistencies (if required, depending on the analysis)
# Example: Check for negative values or extremely high values
data[numerical_cols] = data[numerical_cols].apply(lambda x: np.where(x < 0, 0, x))

# 8. Verify the data types and look for inconsistencies
print(data.dtypes)

# 9. Final cleaned dataset preview
print(data.head())